#!/usr/bin/python3

import os
import subprocess
from gi.repository import GObject, Nemo


class CompressPDFExtension(GObject.GObject, Nemo.MenuProvider):
    def get_file_items(self, *args):
        # Nemo API signatures differ slightly between versions.
        files = args[-1] if args else []
        if not files or len(files) != 1:
            return []

        file_info = files[0]

        try:
            if file_info.get_uri_scheme() != "file":
                return []
        except Exception:
            return []

        path = file_info.get_location().get_path()
        if not path or not path.lower().endswith(".pdf"):
            return []

        item = Nemo.MenuItem(
            name="CompressPDF::Compress",
            label="Compress PDF",
            tip="Compress PDF dan buat salinan _compress",
            icon="document-save",
        )
        item.connect("activate", self.compress_pdf, path)
        return [item]

    def compress_pdf(self, menu, input_path):
        directory = os.path.dirname(input_path)
        filename = os.path.basename(input_path)
        name, _ext = os.path.splitext(filename)

        output = os.path.join(directory, f"{name}_compress.pdf")
        counter = 1
        while os.path.exists(output):
            output = os.path.join(directory, f"{name}_compress_{counter}.pdf")
            counter += 1

        try:
            result = subprocess.run(
                [
                    "gs",
                    "-sDEVICE=pdfwrite",
                    "-dCompatibilityLevel=1.4",
                    "-dPDFSETTINGS=/ebook",
                    "-dNOPAUSE",
                    "-dQUIET",
                    "-dBATCH",
                    f"-sOutputFile={output}",
                    input_path,
                ],
                check=False,
            )

            if result.returncode == 0 and os.path.isfile(output) and os.path.getsize(output) > 0:
                old_size = os.path.getsize(input_path)
                new_size = os.path.getsize(output)
                old_mb = old_size / 1048576
                new_mb = new_size / 1048576
                reduction = (1 - (new_size / old_size)) * 100 if old_size else 0

                # If Ghostscript makes the file larger, keep it but report honestly.
                if reduction >= 0:
                    detail = f"{old_mb:.2f} MB → {new_mb:.2f} MB\nHemat {reduction:.0f}%"
                else:
                    detail = f"{old_mb:.2f} MB → {new_mb:.2f} MB\nUkuran bertambah {abs(reduction):.0f}%"

                subprocess.Popen([
                    "notify-send",
                    "PDF berhasil dikompres",
                    f"{os.path.basename(output)}\n{detail}",
                ])
            else:
                if os.path.exists(output):
                    os.remove(output)
                subprocess.Popen(["notify-send", "Compress PDF gagal", filename])
        except Exception as exc:
            try:
                if os.path.exists(output):
                    os.remove(output)
            except Exception:
                pass
            subprocess.Popen(["notify-send", "Compress PDF gagal", str(exc)])
